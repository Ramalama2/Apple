#!/bin/bash
#
# dumpACPItables, get all Tables from Mac OS X ioreg.
#
# 06-19-2009 AlainTox714
#
# path: /usr/local/bin
#

ACPIdir="/Users/${USER}/Desktop/ACPITables/ACPI-Tables"
[ "$(whoami)" == "root" ] && ACPIdir="/Users/${SUDO_USER}/Desktop/ACPITables/ACPI-Tables"


if [ ! -d ${ACPIdir} ]; then
   mkdir "${ACPIdir}"
else
   rm -rf "${ACPIdir}"/*.*
fi

# Dump ACPI Tables from ioreg
ACPI_Tables="$(ioreg -lw0 | grep 'ACPI Tables' | cut -f2 -d '{' | tr -d '}' | tr ',' '\012')"

iaslOK=
if [ -n "$(which iasl)" ]; then
  iaslOK=1
  cd "${ACPIdir}"
fi

# Extract Tables from Dump
for table in ${ACPI_Tables}; do
    tableName=$(echo $table | cut -f1 -d '=' | tr -d '"')
    printf "${tableName} \n"
    tableData=$(echo "$table" | cut -f2 -d '<' | tr -d '>')
    echo "$tableData" | xxd -r -p > "${ACPIdir}/${tableName}.aml"
    if [ -n "${iaslOK}" ]; then
      iasl -d "${tableName}.aml" 1>/dev/null 2>&1
    fi  
done