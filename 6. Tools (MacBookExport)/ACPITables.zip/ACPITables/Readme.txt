PUT this „ACPITables“ folder to desktop and run ACPIDump.sh!
(If double click doesn’t work, open it with Terminal!)