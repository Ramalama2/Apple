PUT this „SMC“ folder to desktop and run DumpSMC.sh!
(If double click doesn’t work, open it with Terminal!)