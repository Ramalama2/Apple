sudo ~/Desktop/PCIDump/bin/lspci -nnvvxxx > ~/Desktop/PCIDump/lspcinnvvxxx.txt
sudo ~/Desktop/PCIDump/bin/lspci -tvnn > ~/Desktop/PCIDump/lspcitvnn.txt
