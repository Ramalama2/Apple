PUT this „PCIDump“ folder to desktop and run PCIDump.sh!
(If double click doesn’t work, open it with Terminal!)

—> You need to install the kext and reboot! (You can use Kextutil)